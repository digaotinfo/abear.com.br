(function(){Tasks = new Mongo.Collection("tasks");

if (Meteor.isClient) {
	///** TASKS
	Template.body.helpers({

		tasks: function(){
			return Tasks.find({}, {sort: {createdAt: -1}});
		}
	});

	Template.body.events({

		//****** ADD
		"submit .new-task": function(event) {
			var text = event.target.text.value;

			if (text.length == 0) {
				// console.log('Preencha o campo de tarefa');
				// alert('Preencha o campo de tarefa');
			} else {
				Tasks.insert({
					text: text,
					createdAt: new Date()
				});

				event.target.text.value = "";
				
			}

			return false;
		},





		//****** UPDATE
		"click .toggle-checked": function() {
			Tasks.update(this._id, {$set: {checked: ! this.checked}});
		},






		//****** DELETE
		"click .delete": function() {
			Tasks.remove(this._id);
		}


	});
}

if (Meteor.isServer) {
	Meteor.startup(function () {
		// code to run on server at startup
	});
}

})();
